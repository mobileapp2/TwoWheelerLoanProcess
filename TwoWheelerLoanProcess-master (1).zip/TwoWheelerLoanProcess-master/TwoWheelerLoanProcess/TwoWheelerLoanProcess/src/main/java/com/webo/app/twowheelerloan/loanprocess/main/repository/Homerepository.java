package com.webo.app.twowheelerloan.loanprocess.main.repository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.webo.app.twowheelerloan.loanprocess.main.model.Cibil;

@Repository

public interface Homerepository extends CrudRepository<Cibil, Integer>{

	public static void main(String[] args) {
		
	}
		

		
		

	}


