package com.webo.app.twowheelerloan.loanprocess.main.service;

import com.webo.app.twowheelerloan.loanprocess.main.model.Bike_Details;

public interface HomeService {


	void saveBikeDetailsController(Bike_Details bidt);
}
