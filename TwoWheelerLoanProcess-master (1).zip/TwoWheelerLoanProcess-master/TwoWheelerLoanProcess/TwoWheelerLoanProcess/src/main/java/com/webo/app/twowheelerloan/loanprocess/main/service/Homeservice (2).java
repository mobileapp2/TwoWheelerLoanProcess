package com.webo.app.twowheelerloan.loanprocess.main.service;

import com.webo.app.twowheelerloan.loanprocess.main.model.GaurantorDetails;

public interface Homeservice {

	public void savedata(GaurantorDetails gd);

	
	
	
	

}
